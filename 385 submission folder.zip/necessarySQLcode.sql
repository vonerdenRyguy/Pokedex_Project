-- alters spriteimages
ALTER TABLE trialrun.spriteimages
DROP COLUMN filename;

ALTER TABLE trialrun.pokedex
DROP COLUMN name,
DROP COLUMN profile,
DROP COLUMN image;

-- alters pokemon
ALTER TABLE trialrun.pokemon
CHANGE COLUMN `Sp. Def` sp_def INT;

ALTER TABLE trialrun.pokemon
CHANGE COLUMN `Sp. Atk` sp_atk INT;

ALTER TABLE trialrun.pokemon
CHANGE COLUMN `ï»¿ID` id INT;



-- creates partyofsix where i store and reuse my data
CREATE TABLE partyOfSix (
    name VARCHAR(255),
    type1 VARCHAR(255),
    hp INT
);

-- creates pokeDescription where descriptions are held
CREATE TABLE pokeDescription (
    id INT,
    pokemon_name VARCHAR(255),
    description VARCHAR(255)
);

-- creates a table  called pokemonnames so we can fully implement pokeDescription
CREATE TABLE pokemonnames AS
SELECT DISTINCT p.id, po.Name
FROM pokedex p
JOIN pokemon po ON p.id = po.id;

-- inserts data into pokeDescription
INSERT INTO pokedescription (ID, pokemon_name, description)
SELECT
    pokedex.id,
    pokemonnames.Name,
    pokedex.description
FROM
    pokedex
JOIN
    pokemonnames ON pokedex.id = pokemonnames.id;
    
-- DROP TABLE pokedescription;


-- this fixes errors and typos in the pokedescription table
UPDATE pokedescription
SET description = 
    CASE
        WHEN description LIKE CONCAT('%', pokemon_name, '%') THEN
            CONCAT('This Pokemon', SUBSTRING(description, LENGTH(pokemon_name) + 1))
        WHEN description LIKE CONCAT('%', pokemon_name, '%''s%') THEN
            CONCAT('This Pokemon''s', SUBSTRING(description, LENGTH(pokemon_name) + 3))
        ELSE description
    END;
    
    -- Replace occurrences of Pokemon names with "This Pokemon"
UPDATE pokedescription
SET description = REPLACE(description, 'Bulbasaur', 'This Pokemon')
WHERE description LIKE '%Bulbasaur%';

UPDATE pokedescription
SET description = REPLACE(description, 'Ivysaur', 'This Pokemon')
WHERE description LIKE '%Ivysaur%';

-- Continue the above UPDATE statement for each Pokemon name
-- Handle potential misspellings
UPDATE pokedescription
SET description = REPLACE(description, 'Pidgeot', 'this Pokemon')
WHERE description LIKE '%Pidgeot%';

UPDATE pokedescription
SET description = REPLACE(description, 'Ekans', 'this Pokemon')
WHERE description LIKE '%Ekans%';

UPDATE pokedescription
SET description = REPLACE(description, 'Sandslash', 'this Pokemon')
WHERE description LIKE '%Sandslash%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonorina', 'Pokemon')
WHERE description LIKE '%Pokemonorina%';

UPDATE pokedescription
SET description = REPLACE(description, 'Clefairy', 'this Pokemon')
WHERE description LIKE '%Clefairy%';

UPDATE pokedescription
SET description = REPLACE(description, 'Gloom', 'this Pokemon')
WHERE description LIKE '%Gloom%';

UPDATE pokedescription
SET description = REPLACE(description, 'Diglett', 'these Pokemon')
WHERE description LIKE '%Diglett%';

UPDATE pokedescription
SET description = REPLACE(description, 'Meowth', 'this Pokemon')
WHERE description LIKE '%Meowth%';

UPDATE pokedescription
SET description = REPLACE(description, 'Psyduck', 'this Pokemon')
WHERE description LIKE '%Psyduck%';

UPDATE pokedescription
SET description = REPLACE(description, 'Mankey', 'these Pokemon')
WHERE description LIKE '%Mankey%';

UPDATE pokedescription
SET description = REPLACE(description, 'Poliwag', 'This Pokemon''s')
WHERE description LIKE '%Poliwag%';

UPDATE pokedescription
SET description = REPLACE(description, 'Slowbro', 'this Pokemon')
WHERE description LIKE '%Slowbo%';

UPDATE pokedescription
SET description = REPLACE(description, 'Magnemite', 'this Pokemon''s')
WHERE description LIKE '%Magnemite%';

UPDATE pokedescription
SET description = REPLACE(description, 'Magneton', 'of these Pokemon')
WHERE description LIKE '%Magneton%';

UPDATE pokedescription
SET description = REPLACE(description, 'Farfetch''d', 'This Pokemon')
WHERE description LIKE '%Farfetch''d%';

UPDATE pokedescription
SET description = REPLACE(description, 'Dodrio', 'this Pokemon')
WHERE description LIKE '%Dodrio%';

UPDATE pokedescription
SET description = REPLACE(description, 'Grimer', 'these Pokemon')
WHERE description LIKE '%Grimer%';

UPDATE pokedescription
SET description = REPLACE(description, 'Shelder', 'this Pokemon')
WHERE description LIKE '%Shelder%';

UPDATE pokedescription
SET description = REPLACE(description, 'Haunter', 'This Pokemon')
WHERE description LIKE '%Haunter%';

UPDATE pokedescription
SET description = REPLACE(description, 'Gengar', 'This Pokemon')
WHERE description LIKE '%Gengar%';

UPDATE pokedescription
SET description = REPLACE(description, 'Drowzee', 'this Pokemon')
WHERE description LIKE '%Drowzee%';

UPDATE pokedescription
SET description = REPLACE(description, 'Hypno', 'this Pokemon')
WHERE description LIKE '%Hypno%';

UPDATE pokedescription
SET description = REPLACE(description, 'This PokemonPokemon are', 'There are')
WHERE description LIKE '%This PokemonPokemon are%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonectrode', 'This Pokemon')
WHERE description LIKE '%This Pokemonectrode%';

UPDATE pokedescription
SET description = REPLACE(description, 'Exeggcute', 'of these Pokemon')
WHERE description LIKE '%Exeggcute%';

UPDATE pokedescription
SET description = REPLACE(description, 'Exeggutor', 'this Pokemon')
WHERE description LIKE '%Exeggutor%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonokemoner, Mudkip', 'This Pokemon')
WHERE description LIKE '%This Pokemonokemoner, Mudkip%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonmonon, Zigzagoon', 'This Pokemon')
WHERE description LIKE '%This Pokemonmonon, Zigzagoon%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonnting, Linoone', 'This Pokemon')
WHERE description LIKE '%This Pokemonnting, Linoone%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemon attacked, Cascoon', 'When attacked, this Pokemon')
WHERE description LIKE '%This Pokemon attacked, Cascoon%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonustox', 'this Pokemon')
WHERE description LIKE '%This Pokemonustox%';

UPDATE pokedescription
SET description = REPLACE(description, 'Lombre', 'This Pokemon')
WHERE description LIKE '%Lombre%';

UPDATE pokedescription
SET description = REPLACE(description, 'Ludicolo', 'this Pokemon')
WHERE description LIKE '%Ludicolo%';

UPDATE pokedescription
SET description = REPLACE(description, 'Nuzleaf', 'this Pokemon')
WHERE description LIKE '%Nuzleaf%';

UPDATE pokedescription
SET description = REPLACE(description, 'Swellow', 'of this Pokemon')
WHERE description LIKE '%Swellow%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonish', 'This Pokemon')
WHERE description LIKE '%This Pokemonish%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonask', 'This Pokemon')
WHERE description LIKE '%This Pokemonask%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonmonis', 'This Pokemon is')
WHERE description LIKE '%This Pokemonmonis%';

-- -------- BREAK!
UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemoniclus', 'This Pokemon')
WHERE description LIKE '%This Pokemoniclus%';

UPDATE pokedescription
SET description = REPLACE(description, 'Vanillite', 'this Pokemon')
WHERE description LIKE '%Vanillite%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonmon are terrified of Jellicent. It’s rumored to drag them into the sea and steal their lives away.', 'Most of this Pokémon’s body composition is identical to sea water. It makes sunken ships its lair.')
WHERE description LIKE '%This Pokemonmon are terrified of Jellicent. It’s rumored to drag them into the sea and steal their lives away.%';

UPDATE pokedescription
SET description = REPLACE(description, 'monhes through', ' is active in')
WHERE description LIKE '%monhes through%';

UPDATE pokedescription
SET description = REPLACE(description, 'Spectrier', 'this Pokemon')
WHERE description LIKE '%Spectrier%';

-- Break!

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonast', 'Pokemon')
WHERE description LIKE '%Pokemonast%';

UPDATE pokedescription
SET description = REPLACE(description, 'a Spritzee', 'one of this Pokemon')
WHERE description LIKE '%a Spritzee%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemont, Hawlucha', 'Pokemon')
WHERE description LIKE '%Pokemont, Hawlucha%';

UPDATE pokedescription
SET description = REPLACE(description, 'Carbink', 'these Pokemon')
WHERE description LIKE '%Carbink%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonokemongo', 'Pokemon')
WHERE description LIKE '%Pokemonokemongo%';

UPDATE pokedescription
SET description = REPLACE(description, 'Klefki', 'this Pokemon')
WHERE description LIKE '%Klefki%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonokemongo', 'Pokemon')
WHERE description LIKE '%Pokemonokemongo%';

-- Break!
UPDATE pokedescription
SET description = REPLACE(description, 'Pokemoncts it', 'Pokemon')
WHERE description LIKE '%Pokemoncts it%';

UPDATE pokedescription
SET description = REPLACE(description, 'Larvesta', 'this Pokemon')
WHERE description LIKE '%Larvesta%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonhiram', 'Pokemon')
WHERE description LIKE '%Pokemonhiram%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pyroar', 'this Pokemon')
WHERE description LIKE '%Pyroar%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonokemonmperature', 'The temperature')
WHERE description LIKE '%This Pokemonokemonmperature%';

UPDATE pokedescription
SET description = REPLACE(description, 'Flabébé', 'This Pokemon')
WHERE description LIKE '%Flabébé%';

UPDATE pokedescription
SET description = REPLACE(description, 'Floette', 'This Pokemon')
WHERE description LIKE '%Floette%';

-- Break!

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonkémon', 'Pokemon')
WHERE description LIKE '%Pokemonkémon%';

UPDATE pokedescription
SET description = REPLACE(description, 'This PokemonPokemonggs', 'The eggs')
WHERE description LIKE '%This PokemonPokemonggs%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonmon its', 'This Pokemon has')
WHERE description LIKE '%This Pokemonmon its%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonn', 'Bathed in')
WHERE description LIKE '%This Pokemonn%';

UPDATE pokedescription
SET description = REPLACE(description, 'This PokemonPokemonits', 'Its')
WHERE description LIKE '%This PokemonPokemonits%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemontheir', 'Around their')
WHERE description LIKE '%This Pokemontheir%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonokemones', 'This Pokemon loves')
WHERE description LIKE '%This Pokemonokemones%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonbeen', 'Pokemon has been')
WHERE description LIKE '%Pokemonbeen%';

UPDATE pokedescription
SET description = REPLACE(description, 'Pokemonokemon', 'Pokemon')
WHERE description LIKE '%Pokemonokemon%';

UPDATE pokedescription
SET description = REPLACE(description, 'This Pokemonection of the swirl', 'The swirl')
WHERE description LIKE '%This Pokemonection of the swirl%';