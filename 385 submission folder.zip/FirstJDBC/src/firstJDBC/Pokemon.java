package firstJDBC;

import javax.swing.ImageIcon;

public class Pokemon {
    private String name;
    private ImageIcon image; // You may replace ImageIcon with the appropriate image representation
    private String type1;
    private int hp;

    // Constructors, getters, and setters

    public Pokemon() {
        // Default constructor
    }

    public Pokemon(String name, ImageIcon image, String type1, int hp) {
        this.name = name;
        this.image = image;
        this.type1 = type1;
        this.hp = hp;
    }

    // Getters and setters for each field

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ImageIcon getImage() {
        return image;
    }

    public void setImage(ImageIcon image) {
        this.image = image;
    }

    public String getType1() {
        return type1;
    }

    public void setType1(String type1) {
        this.type1 = type1;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }
}

