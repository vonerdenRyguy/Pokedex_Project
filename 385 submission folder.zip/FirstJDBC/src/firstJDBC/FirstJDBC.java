package firstJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FirstJDBC {
    
    // network connection
    private Connection connect = null;
    // thing sent to database
    private Statement statement = null;
    // store output from the database
    private ResultSet resultSet = null;
    
    public void readData() throws Exception {
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            String userName = "root";
            String password = "2591";
            
            connect = DriverManager.getConnection("jdbc:mysql://localhost/classicmodels?" 
                    + "user=" + userName + "&password=" + password);
            
            statement = connect.createStatement();
            
            resultSet = statement.executeQuery("SELECT * FROM classicmodels.customers;");
            
            writeCustomerData(resultSet);
            
            writeMetaData(resultSet);
            
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            close();
            
        }
    }
    
    private void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void writeCustomerData(ResultSet resultSet) throws SQLException {
        while(resultSet.next()) {
            int customerNumber = resultSet.getInt("customerNumber");
            String customerName = resultSet.getString("customerName");
            double creditLimit = resultSet.getDouble("creditLimit");
            
            System.out.print("Customer num = " + customerNumber);
            System.out.print(" Customer name = " + customerName);
            System.out.print(" Customer Credit Limit = " + creditLimit + "\n");

        }
    }
    
    private void writeMetaData(ResultSet resultSet) throws SQLException {
        System.out.println("********************************");
        System.out.println("The columns are:");
        for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
            System.out.println("Column " + i + " = " + resultSet.getMetaData().getColumnName(i));
        }
        System.out.println("********************************");
    }
    
    public static void main(String[] args) throws Exception {
        FirstJDBC simpleConnection = new FirstJDBC();
        simpleConnection.readData();
    }
}
