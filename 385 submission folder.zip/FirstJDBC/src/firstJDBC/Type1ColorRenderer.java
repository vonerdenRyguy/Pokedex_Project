package firstJDBC;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class Type1ColorRenderer extends DefaultTableCellRenderer {
    private static final long serialVersionUID = 1L;

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
            int row, int column) {
        Component rendererComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
                column);

        String type1 = (String) table.getValueAt(row, 3);

        switch (type1) {
            case "Grass":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(144, 238, 144));
                break;
            case "Fire":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(255, 69, 0));
                break;
            case "Water":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(0, 191, 255));
                break;
            case "Bug":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(168, 184, 32)); 
                break;
            case "Electric":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(255, 223, 0)); 
                break;
            case "Psychic":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(219, 112, 147));
                break;
            case "Dark":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.WHITE);
                rendererComponent.setBackground(new Color(139, 0, 0));
                break;
            case "Fighting":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(255, 99, 71));
                break;
            case "Ice":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(173, 216, 230));
                break;
            case "Dragon":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.WHITE);
                rendererComponent.setBackground(new Color(0, 0, 128));
                break;
            case "Normal":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(169, 169, 169));
                break;
            case "Ground":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(226,191,101));
                break;
            case "Ghost":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(115,87,151)); 
                break;
            case "Fairy":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(255, 182, 193)); 
                break;
            case "Poison":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.WHITE);
                rendererComponent.setBackground(new Color(128, 0, 128)); 
                break;
            case "Rock":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.WHITE);
                rendererComponent.setBackground(new Color(139, 69, 19));
                break;
            case "Flying":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(new Color(168, 144, 240));
                break;
            case "Steel":
                rendererComponent.setFont(getFont().deriveFont(Font.BOLD, 13));
                rendererComponent.setForeground(Color.BLACK);
                rendererComponent.setBackground(Color.WHITE);
                break;
            default:
                rendererComponent.setBackground(table.getBackground());
                break;
        }

        return rendererComponent;
    }
}
