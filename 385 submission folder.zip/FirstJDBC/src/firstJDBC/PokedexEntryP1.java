package firstJDBC;

import javax.swing.*;

class PokedexEntryP1 {
    private int id;
    private ImageIcon imageIcon;
    private String name;
    private int hp;
    private int attack;
    private int defense;
    private int spAtk;
    private int spDef;
    private int speed;
    private int gen;

    public PokedexEntryP1(int id, ImageIcon imageIcon, String name, int hp, int attack, int defense, int spAtk, int spDef, int speed, int gen) {
        this.id = id;
        this.imageIcon = imageIcon;
        this.name = name;
        this.hp = hp;
        this.attack = attack;
        this.defense = defense;
        this.spAtk = spAtk;
        this.spDef = spDef;
        this.speed = speed;
        this.gen = gen;
    }

    public int getId() {
        return id;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public String getName() {
        return name;
    }

    public int getHp() {
        return hp;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpAtk() {
        return spAtk;
    }

    public int getSpDef() {
        return spDef;
    }

    public int getSpeed() {
        return speed;
    }

    public int getGen() {
        return gen;
    }

    public String getStatsInfo() {
        return "HP: " + hp +
                ", Attack: " + attack +
                ", Defense: " + defense +
                ", Sp. Atk: " + spAtk +
                ", Sp. Def: " + spDef +
                ", Speed: " + speed +
                ", Generation: " + gen;
    }

    @Override
    public String toString() {
        return name;
    }
}