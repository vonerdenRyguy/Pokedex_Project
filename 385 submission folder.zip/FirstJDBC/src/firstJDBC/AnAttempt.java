package firstJDBC;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.Color;

/**
 * Title: Assignment #7
 * @author Ryan vonErden
 * Class: CSE 385
 *
 */

public class AnAttempt extends JPanel implements ActionListener {

    // variable to store the result of the calculator
    private JTextField resultText;
    // the current number of shown on the resultText
    // allows us to do multiple calculations on the same result
    private double currentResult = 0;
    // always a number that stores the number the user chose 
    private String currentInput = " ";
    // the operator selected by the user 
    private char chosenOperator = ' ';
    // tells us if a number or operator was selected last
    private boolean latestInput = true;

    // method creates all the buttons to be managed
    // parameter value is not necessary
    public AnAttempt() {
        //set the layout manager of this JFrame
        setLayout(new GridBagLayout());
        
        //creates an object to stores the parameters of the grid bag
        //such as the grid width, height, current x, current y, etc
        GridBagConstraints c = new GridBagConstraints();

        // Sets the size and features of resultText
        resultText = new JTextField(20);
        resultText.setEditable(false);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 5;
        c.gridx = 0;
        c.gridy = 0;
        add(resultText, c);

        // Create buttons for digits 1-9 in a loop
        // sets up the buttons to appear like the standard calculator somewhat
        for (int i = 1; i <= 9; i++) {
            JButton button = createNumberButton(Integer.toString(i));
            c.fill = GridBagConstraints.BOTH;
            c.gridwidth = 1;
            // calculations to organize the buttons
            c.gridx = (i - 1) % 3;
            c.gridy = (i - 1) / 3 + 1;
            add(button, c);
        }

        // Adds the 0 button
        JButton zeroButton = createNumberButton("0");
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = 1;
        c.gridx = 1;
        c.gridy = 4;
        add(zeroButton, c);

        // Create buttons for  the first 3 operators
        // along with size
        String[] operators1 = { "+", "-", "*"};
        for (int i = 0; i < operators1.length; i++) {
            JButton button = createOperatorButton(operators1[i]);
            c.fill = GridBagConstraints.BOTH;
            c.gridwidth = 1;
            c.gridx = 3;
            c.gridy = i + 1;
            add(button, c);
        }
        
        // Creates the buttons for the last 3 operators
        // along with size
        String[] operators2 = {"/", "=", "C"};
        for (int i = 0; i < operators2.length; i++) {
            JButton button = createOperatorButton(operators2[i]);
            c.fill = GridBagConstraints.BOTH;
            c.gridwidth = 1;
            c.gridx = 4;
            c.gridy = i + 1;
            add(button, c);
        }
        
    }

    // the method that gets called for every number
    // the parameter value is the string of each number
    private JButton createNumberButton(String label) {
        // this creates a new button and adds the action listener
        JButton button = new JButton(label);
        // adds the action listener to the button
        button.addActionListener(this);
        return button;
    }

    // method that creates a button for the operators
    private JButton createOperatorButton(String label) {
        JButton button = createNumberButton(label);
        // sets font and color for each operator
        button.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 21));
        button.setBackground(new Color(128, 128, 128));
        return button;
    }

    // method that manages the what every button does
    public void actionPerformed(ActionEvent e) {
        // variable that allows me to use the value stored
        // to determine what action should be taken when
        String actionCommand = e.getActionCommand();
        // checks if a button with a number between 0-9 was chosen
        if (actionCommand.matches("[0-9]")) {
            if (latestInput) {
                currentInput = actionCommand;
                latestInput = false;
            } else {
                currentInput += actionCommand;
            }
            resultText.setText(currentInput);
        // check if the C button was chosen
        } else if (actionCommand.equals("C")) {
            clear();
        // checks if the = operator was chosen
        } else if (actionCommand.equals("=")) {
            equals();
        // if nothing else was chosen then an operator was chosen
        } else {
            if (!latestInput) {
                equals();
            }
            // chosenOperator equals the operator that was chosen(simple)
            chosenOperator = actionCommand.charAt(0);
            // set to true because an operator was chosen and not a number
            latestInput = true;
            // sets the currentResult as the first operand
            currentInput = Double.toString(currentResult);
            resultText.setText(currentInput);
        }
    }

    // sets the variables back to their default values
    private void clear() {
        resultText.setText("");
        currentResult = 0;
        currentInput = "";
        chosenOperator = ' ';
        latestInput = true;
    }

    // method that runs when the '=' button is chosen
    private void equals() {
        // runs if a number was the last input
        // if an operator was the last input, nothing happens
        if (!latestInput) {
            double nextNum = Double.parseDouble(currentInput);
            if (chosenOperator == '+') {
                currentResult += nextNum;
            } else if (chosenOperator == '-') {
                currentResult -= nextNum;
            } else if (chosenOperator == '*') {
                currentResult *= nextNum;
            } else if (chosenOperator == '/') {
                // prints a statement if nextNum equals 0
                if (nextNum == 0) {
                    resultText.setText("NaN (Press C to refresh calculator)");
                    return;
                }
                currentResult /= nextNum;
            } else {
                currentResult = nextNum;
            }
            // allows the user to immediately select numbers after the equals
            // and the last operator chosen will apply to that number and 
            // perform on the result(low key it's a better idea than the real calculator)
            resultText.setText(Double.toString(currentResult));
            latestInput = true;
        }
    }
    
    // method creates a menu bar
    public static JMenuBar createMenuBar(){
        JMenuBar menuBar;
        JMenu menu;
               
        menuBar = new JMenuBar();        
        menu = new JMenu("Basic");
        menuBar.add(menu);
        return menuBar;
        
    }

    public static void main(String[] args) {     
        JFrame frame = new JFrame("Simple Calculator");
        //make it so that when we click on the X button in the corner it actually closes the program
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // adds an instance of the AnAttempt method to run
        frame.add(new AnAttempt());
        // add JMenuBar
        frame.setJMenuBar(createMenuBar());
        // set size
        frame.setSize(350, 600);
        // set so user can view calculator
        frame.setVisible(true);
    }
}
