package firstJDBC;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Assignment7 extends JPanel implements ActionListener {

    private JTextField display;
    private double currentResult = 0;
    private String currentInput = "";
    private char lastOperator = ' ';
    private boolean newInput = true;

    public Assignment7() {
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        // Create the display field
        display = new JTextField(15);
        display.setEditable(false);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 4;
        c.gridx = 0;
        c.gridy = 0;
        add(display, c);

        // Create buttons for digits 0-9
        for (int i = 1; i <= 9; i++) {
            JButton button = createButton(Integer.toString(i));
            c.fill = GridBagConstraints.BOTH;
            c.gridwidth = 1;
            c.gridx = (i - 1) % 3;
            c.gridy = (i - 1) / 3 + 1;
            add(button, c);
        }

        // Add 0 button
        JButton zeroButton = createButton("0");
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 4;
        add(zeroButton, c);

        // Create buttons for operators
        String[] operators = { "+", "-", "*", "/", "=", "C" };
        for (int i = 0; i < operators.length; i++) {
            JButton button = createOperatorButton(operators[i]);
            c.fill = GridBagConstraints.BOTH;
            c.gridwidth = 1;
            c.gridx = 2 + i % 2;
            c.gridy = i / 2 + 1;
            add(button, c);
        }
    }

    private JButton createButton(String label) {
        JButton button = new JButton(label);
        button.addActionListener(this);
        return button;
    }

    private JButton createOperatorButton(String label) {
        JButton button = createButton(label);
        button.setFont(new Font("Arial", Font.BOLD, 20));
        if (Character.isDigit(label.charAt(0))) {
            button.setBackground(Color.WHITE);
        } else {
            button.setBackground(new Color(224, 224, 224));
        }
        return button;
    
    }

    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();

        if (actionCommand.matches("[0-9]")) {
            if (newInput) {
                currentInput = actionCommand;
                newInput = false;
            } else {
                currentInput += actionCommand;
            }
            display.setText(currentInput);
        } else if (actionCommand.matches("[\\+\\-\\=]")) {
            if (!newInput) {
                double value = Double.parseDouble(currentInput);
                if (lastOperator == '+') {
                    currentResult += value;
                } else if (lastOperator == '-') {
                    currentResult -= value;
                } else {
                    currentResult = value;
                }
                display.setText(Double.toString(currentResult));
                newInput = true;
                lastOperator = actionCommand.charAt(0);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Standard Calculator");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setJMenuBar(createMenuBar());
            frame.add(new AnAttempt());
            frame.setSize(300, 300);
            frame.setVisible(true);
        });
    }

    public static JMenuBar createMenuBar() {
        JMenuBar menuBar;
        JMenu menu, subMenu;
        JMenuItem menuItem;
        
        menuBar = new JMenuBar();        
        menu = new JMenu("menu bar area");
        
        menuBar.add(menu);
        
        return menuBar;
    }
}

