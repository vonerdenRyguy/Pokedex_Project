package firstJDBC;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
class ACalculator extends JPanel
                        implements ActionListener {


    //this method creates all the components and manages them
    public static void componentManager(Container pane){
        
        //declare multiple buttons that we will use to demonstrate
        //the GridBag and how it works. We will use buttons because 
        //they have clearly visible edges.
        //********************************************************
        //**********NOTICE THAT THERE IS ONLY ONE BUTTON**********
        //********************************************************
        JButton button;
        JTextField tField;
        
        //set the layout manager of this JFrame  
        //layout managers are reactive to the size/shape of the window and are not 
        //based on absolute positions (x, y coordinates)
        //there are multiple different layout managers to choose from
        //with different characteristics
        //GridBag is one of the more powerful and complex     
        pane.setLayout(new GridBagLayout());
        
        //creates an object to stores the parameters of the grid bag
        //such as the grid width, height, current x, current y, etc
        GridBagConstraints c = new GridBagConstraints();
        

        //notice that we do not declare new buttons each time we want to 
        //add a new button to the content pane. Instead, we re-instantiate
        //the button with a new value (in this case just a new text value),
        //set the c to what ever the location of the to-be-added button is,
        //then invoke the add method with the object c.
        //This allows us to quickly 'clone' multiple buttons more quickly than
        //if we had to declare and instantiate a bunch by hand. It also gives
        //us more flexibility becase we could but this code inside a loop and create
        //as many buttons (or other components) as we wanted, which is the real power
        //of this style.
        
        button = new JButton("button 1");//re-instatiate the button (this just happens to be the first time)
        c.fill = GridBagConstraints.HORIZONTAL;//set the button to take up the entire horizontal space in the column it is given (stretch out if it needs to)
        
        //the GridBag does not use pixels to divide the window, instead it uses cells (think like Excel) and you simply
        //specify which cell you want the component to occupy and if you want it to take up multiple cells (default is to use only one)
        c.gridx = 0;//set the button to use the X cell 0
        c.gridy = 0;//set the button to use the Y cell 0
        
        //set this component to use two cells. Think of this like merging cells in Excel
        c.gridwidth = 2;//set this component to use two cells instead of one. This cell and the one two the right
        c.weightx = 1.0;
        c.weighty = 1.0;
        pane.add(button, c);//add the component to the content pane
                
        button = new JButton("button 2");//re-instantiate another button
        c.fill = GridBagConstraints.HORIZONTAL;//set the button to take up the entire horizontal space in the column it is given (stretch out if it needs to)       
        c.gridx = 0;//set the button to use the X cell 0
        c.gridy = 1;//set the button to use the Y cell 1
        c.gridwidth = 1;//reset the grid width back to 1. If we did not do this, then all future components would still be using width 2 like button 1.
        pane.add(button, c);//add the button
        
        button = new JButton("button 3");
        c.fill = GridBagConstraints.HORIZONTAL;        
        c.gridx = 1;
        c.gridy = 1;        
        pane.add(button, c);
        
        button = new JButton("button 4");
        c.fill = GridBagConstraints.HORIZONTAL;        
        c.gridx = 0;
        c.gridy = 2;        
        pane.add(button, c);
        
        button = new JButton("button 5");
        c.fill = GridBagConstraints.HORIZONTAL;        
        c.gridx = 1;
        c.gridy = 2;        
        pane.add(button, c);        
        
        //only difference here is this is a text field instead of a button
        //still no functionality yet
        tField = new JTextField(15);//instantiate the text field and make it 15 characters long
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 3;  
        c.gridwidth = 2;   
        pane.add(tField, c); 
             
    }//end componentManager constructor
    
    //driver method to create the menu bar
    //menus are a type of component but they are managed
    //in a special way because they are displayed in a special location
    //I have created this special drive method to make understanding
    //and managing the menus easier
    public static JMenuBar createMenuBar(){
        //creating and adding menus and menu items follows a three step process: 
        //1. delcare the menu object
        //2. instantiate the menu object
        //3. add the menu object
    
        //1. here we simply declare all the different menu objects that we might need
        JMenuBar menuBar;
        JMenu menu, subMenu;
        JMenuItem menuItem;
        
        //2. once declared, we must instantiate the menu objects
        menuBar = new JMenuBar();        
        menu = new JMenu("menu bar area");
        
        //3. once instantiated, the menu objects must be added
        menuBar.add(menu);
        
        //other menu items (such as the actual items in the menu)
        //can now be added from here
        
        //menuItem = new JMenuItem(icon);
        //menu.add(menuItem);
        
        //now that all the menu items have been added to the menu bar (the parent object that stored everything
        //we can return that to the caller (found in the windowManager() ) who will now add that entire 
        //menu and all the menu items to the JFrame window
        return menuBar;
        
    }//end createMenu()
    
    //this method controls all the functions of the components
    //nothing to see here yet...
    public void actionPerformed(ActionEvent e){
    
            
    }//end actionPerformed
    
    //driver method to create and manage the window
    //this includes both the content pane and the menu pane
    //this is the root pane (which means technically it also
    //contains the layered pane and the glass pane but we dont
    //care about those in this class. Those are for drawing and
    //other fancy affects). 
    //both of these are contained inside of the window 
    //which in this case is a JFrame
    private static void windowManager(){
    
        //create a new JFrame to store everything and set the title of the frame
        JFrame frame = new JFrame("title area");
        
        //make it so that when we click on the X button in the corner it actually closes the program...
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //invoke the menu bar driver method to create the menu bar and set this frame's 
        //menu bar equal to the return value of that method
        frame.setJMenuBar(createMenuBar());
        
        //start adding components to the JFrame using our component manager method
        //and give it the content panel of this frame
        //remember that the content pane is where components are stored inside a JFrame
        componentManager(frame.getContentPane());        
        
        //frame.setContentPane(newContentPane); //put our application window (newContentPane) 
        //inside the frame that we created at the beginning of this method
        
        frame.setSize(400,630);//sets the size of the frame
        //forces the frame to be of size 400 x 400 pixels 
        
        //frame.pack();//sets the size of the frame
        //automatically sets the size to the 'minimal' size needed to store all the components of the frame
        
        //can only use one size technique: setSize() or pack(). 
        //the last one called will overwrite the first one called.
        
        frame.setVisible(true);
        //must set to true otherwise our window is invisible...
    }//end createAndShow()

    public static void main(String args[]){
        windowManager();
    }//end main()
}//end class
